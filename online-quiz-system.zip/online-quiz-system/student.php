<?php
include('./partials/header.php');
include('./conn/conn.php');
include('./partials/modal.php');
?>

<div class="main">
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <a class="navbar-brand ml-4" href="#">Online Quiz System</a>

    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item active">
                    <a href="./student.php" class="nav-link">Home<span class="sr-only">(current)</span></a>
                </li>
            </ul>
        </div>


        <div class="collapse navbar-collapse mr-4" id="navbarSupportContent">
            <div class="ml-auto">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a href="./index.php" class="nav-link">Log out</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>


    <div id="pills-home">
        <h2 id="welcome-teacher">Welcome Student!</h2>
        <small>This is a student area where you can take quizzes, and the result will be sent to the teacher <br> area after you have submitted.</small>
        <br>
        <button id="takeQuiz">
            <a href="./take-quiz.php" class="nav-link" style="color: inherit">Take Quiz <i class="fa-solid fa-arrow-right"></i></a>
        </button>
    </div>
</div>

<?php
include('./partials/footer.php');
?>